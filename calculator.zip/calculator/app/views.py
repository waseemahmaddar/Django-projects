from django.shortcuts import render 
from django.http import HttpResponse

# Create your views here.
def index(request):
    return render(request,'index.html')
def submitmyform(request):
    q = request.GET.get('mytext')
    try:
        ans = eval(q)
        mydic = {
            "q":q,
            "ans":ans,
            "result":True
        }
        return render(request,"index.html",context = mydic)
    except:
        mydic = {
            "error":True,
            "msg":"Error"
        }
        return render(request,"index.html",context = mydic)
