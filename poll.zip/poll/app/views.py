from django.shortcuts import render
from django.http import HttpResponse
# Create your views here.
arr = ['python','perl','php','c','c++','java','reactjs','js']

def index(request):
    mydic = {
        "arr":arr
    }
    return render(request,"index.html",context = mydic)
# globel constants
mydic = dict()
lst = []
def submitquery(request):
    q = request.GET.get("mytext")
    lst.append(q)
    for each in lst:
        res = lst.count(each)
        mydic[each] = res
    mydictionery = {
        "arr":arr,
        "mydic":mydic
    }
    return render(request,"index.html",context = mydictionery)  
